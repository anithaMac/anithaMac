//
//  ScrollViewController.swift
//  test
//
//  Created by Apple on 10/07/21.
//

import UIKit


class ScrollViewController: UIViewController {

    @IBOutlet weak var usertxt: UITextField!
    @IBOutlet weak var passwordtxt: UITextField!
    
    @IBOutlet weak var fogot_action: UIButton!
    @IBAction func button_action(_ sender: UIButton) {
        
       
        LoginpostAction()
        
    }
    @IBOutlet weak var login_action: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
   
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
    // Hide the Navigation Bar
            self.navigationController?.setNavigationBarHidden(true, animated: true)
        AppUtility.lockOrientation(.landscape)
    
        }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
    // Show the Navigation Bar
             
        
        
        }
    
    @IBAction func forgotaction(_ sender: Any) {
        print("forgotPasswordButtn tapped")
        
  
          
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ForgotViewController")
        self.present(vc, animated: true)
        postAction()

    }
    func postAction() {
        let Url = String(format: "https://lantoon.net/Lantoon/public/index.php/admin")
        guard let serviceUrl = URL(string: Url) else { return }
        let parameterDictionary = ["uid" : "Nizam","email":"nizamcseb@gmail.com","pass" : "12345678"]
        var request = URLRequest(url: serviceUrl)
        request.httpMethod = "POST"
        request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameterDictionary, options: []) else {
            return
        }
        request.httpBody = httpBody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                } catch {
                    print(error)
                }
            }
        }.resume()
    }
    
    func LoginpostAction() {
      //  let Url = String(format: "https://lantoon.net/Lantoon/public/index.php/admin")
       
        let emailTxtFldtxt = self.usertxt.text
        let passwordFldtxt = self.passwordtxt.text
        let deviceIDStr = "6FGGHH7F56"
        
       let Url = URL(string: "https://lantoon.net/Lantoon/public/UserHandler.php/login?email=\(emailTxtFldtxt ?? "")&pass=\(passwordFldtxt ?? "")&deviceid=\(deviceIDStr)")
//
    
        
       // let url = URL(string: "https://jsonplaceholder.typicode.com/todos")
        guard let requestUrl = Url else { fatalError() }
        // Prepare URL Request Object
        var request = URLRequest(url: requestUrl)
        request.httpMethod = "POST"
         
        // HTTP Request Parameters which will be sent in HTTP Request Body
        let postString = "userId=300&title=My urgent task&completed=false";
        // Set HTTP Request Body
        request.httpBody = postString.data(using: String.Encoding.utf8);
        // Perform HTTP Request
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                
                // Check for Error
                if let error = error {
                    print("Error took place \(error)")
                    return
                }
         
                // Convert HTTP Response Data to a String
                if let data = data, let dataString = String(data: data, encoding: .utf8) {
                    print("Response data string:\n \(dataString)")
                }
        }
        task.resume()
        
}
}
